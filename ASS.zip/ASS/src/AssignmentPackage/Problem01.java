package AssignmentPackage;

import java.util.Iterator;
import java.util.LinkedList;

public class Problem01 {
	
	public LinkedList<Integer> findingPerfectNumber(LinkedList<Integer> L1)
	{
		LinkedList<Integer> L2= new LinkedList<Integer>();	
		 Iterator<Integer> it = L1.iterator();
		 
		 while(it.hasNext())
		 {
			 int a = it.next();
			 int x=0;
			//System.out.println(a); 
			//L2.add(a);
			for(int i =1;i<a;i++)
			{
				if(a%i==0)
				{
					x=x+i;
					//System.out.println(x);
				}
			}
			if(a==x)
			{
				//System.out.println(x);
				L2.add(a);
			}
			 
		 }
		// System.out.println(L2);
		 
		return L2;
		
	}

}
