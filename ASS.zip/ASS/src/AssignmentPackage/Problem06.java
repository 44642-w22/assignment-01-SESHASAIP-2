package AssignmentPackage;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Scanner;
import java.util.Stack;

public class Problem06 {
	public static ArrayList<Integer> lifoFifoStack(Stack s)
	{
		LinkedList<Integer> arr = new LinkedList<Integer>();
		ListIterator it = s.listIterator();
		for(int i =0;i<s.size();i++)
		{
			if(i<s.size()/2)
			{
				
				arr.addLast((Integer) it.next());
			}
			else
			{
				if(it.hasNext())
				{
					arr.addFirst((Integer) it.next());
				}
			}
		}
		//while(it.hasNext())
		//{
			
			//System.out.println(it.next());
		//}
		ArrayList<Integer> ar = new ArrayList<>(arr);
		return ar;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack<Integer> s = new Stack<>();
		System.out.println("Enter the size of the stack");
		Scanner sc = new Scanner(System.in);
		
		int size=sc.nextInt();
		if(size%2==0)
		{
			
		
		
		for(int i =0;i<size;i++)
		{
			System.out.println("Enter the value into stack:");
			s.push(sc.nextInt());
		}
		System.out.println(lifoFifoStack(s));
		
		}
		else
		{
			System.out.println("enter the even number");
		}
	}

}
