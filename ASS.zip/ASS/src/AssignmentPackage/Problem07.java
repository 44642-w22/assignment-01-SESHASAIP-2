package AssignmentPackage;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Scanner;

public class Problem07 {
	public static int gettingDecimalFromBinary(Queue Q)
	{//
	Iterator<Integer> it =Q.iterator();
		//int i=0;
				int sum=0;
		//while(it.hasNext())
				//System.out.println(Q);
		for(int i=0;i<Q.size();i++ )
		{if(it.hasNext())
		{
			int j=(int) it.next();
			//System.out.println("j"+j);
			if(j==1)
			{
			 sum =sum+ (int)(Math.pow(2, i));	
			 //System.out.println("i"+i);
			 //System.out.println("sum"+sum);
			}
			//i=i+1;
		}
		}
		
		return sum;
	}
	public static void main(String[] args) {
		Queue<Integer> Q = new LinkedList<>();
		System.out.println("enter the size of the queue:");
		Scanner sc = new Scanner(System.in);
		int size=sc.nextInt();
		for(int i =0;i<size;i++)
		{
			System.out.println("Enter values into the queue only 1 or 0:");
			int a= sc.nextInt();
			if(a==0 ||a==1)
			  Q.add(a);
			
		}
		System.out.println("Output: "+gettingDecimalFromBinary(Q));
		
	}

}
