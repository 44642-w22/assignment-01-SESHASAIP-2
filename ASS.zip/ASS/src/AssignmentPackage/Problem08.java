package AssignmentPackage;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Problem08 {
	public static ArrayList<Integer> alternatingSequence(Queue Q)
	{
		Deque<Integer> dQ= new ArrayDeque<>(Q);
		Iterator<Integer> it= dQ.iterator();
		System.out.println(dQ);
		
		ArrayList<Integer> arr = new ArrayList<>();
		for(int i =0;i<dQ.size()/2;i++)
		{
			
		arr.add(dQ.removeLast());
		arr.add(dQ.removeFirst());
	}
		//if(dQ.size()==1&&it.hasNext())
		arr.addAll(dQ);
		return arr;
	}
	
	public static void main(String[] args) {
		Queue<Integer> Q = new LinkedList<>(); 
		System.out.println("enter the size of queue");
		Scanner sc = new Scanner(System.in);
		int size = sc.nextInt();
		for(int i =0;i<size;i++)
		{
			System.out.println("enter the value into Q:");
			Q.offer(sc.nextInt());
		}
		System.out.println("Output "+alternatingSequence(Q));
	}

}
