package AssignmentPackage;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Scanner;

public class Problem09 {
	public static ArrayList<Integer> storingOddEven(Queue Q)
	{
		Queue<Integer> list1 = new LinkedList<>();
		Queue<Integer> list2 = new LinkedList<>();
		while(!Q.isEmpty()) {
			int last = (int) Q.poll();
			if(last%2==0) {
				list1.add(last);
			}else {
				list2.add(last);
			}
		
		}
	    ArrayList<Integer> list = new ArrayList<>();
	    while(!list1.isEmpty() || !list2.isEmpty()) {
	    	if(!list1.isEmpty()) {
	    		list.add(list1.poll());
	    	}
	    	if(!list2.isEmpty()) {
	    		list.add(list2.poll());
	    	}
	    }
	    
		return (ArrayList<Integer>) list;	}
	public static void main(String[] args) {
		System.out.println("enter the size of the Q:");
		Scanner sc = new Scanner(System.in);
		int size = sc.nextInt();
		Queue<Integer> Q = new LinkedList<>();
	    for(int i =0;i<size;i++)
	    {
	    	System.out.println("Enter the value into Q:");
	    	Q.add(sc.nextInt());
	    	
	    	
	    }
	    System.out.println(storingOddEven(Q));
	    
		
	}

}
