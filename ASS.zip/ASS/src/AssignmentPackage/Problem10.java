package AssignmentPackage;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;
import java.util.Scanner;

public class Problem10 {
public static String dequeOperations(Deque Q,int[] arr)
{
	char a='\u0000';
	for(int i=0;i<arr.length;i++)
	{
		if(arr[i]==1)
		{
			if(Q.isEmpty()==false)
			{
				//String r=(String) Q.removeFirst();
				a=(char) Q.removeFirst();
				//System.out.println(a);
			}
		}
		else if (arr[i]==0)
		{
			if(a != '\u0000')
			{
			Q.addFirst(a);
			a='\u0000';
			}
		}
		
	}
	Iterator<Object> it = Q.iterator();
	String res = "";
	while(it.hasNext())
	{
		res= res+String.valueOf(it.next());
	}
	
	return res;
	
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("enter the size pf array");
		Scanner sc = new Scanner(System.in);
		Deque<Character> Q = new ArrayDeque<>();
		int len = sc.nextInt();
		int arr[]=null;
		if(len>=0)
		arr= new int[len];
		for(int k=0;k<len;k++)
			
		{
			System.out.println("enter the value into array 1 or 0");
			int d =sc.nextInt();
			if(d==1 || d==0)
			{
				arr[k]=d;
			}
			
		}
		System.out.println("choose input type string or chars ");
		String g= sc.next();
		if(g.equalsIgnoreCase("String"))
		{
			System.out.println("Enter the String:");
			String a=sc.next();
			for(int i=0;i<a.length();i++)
			{
				Q.add(a.charAt(i));
				//System.out.println(Q);
			}
			

			//Deque<String> Q1 = new ArrayDeque<>();
			//int size = sc.nextInt();
			//for(int i =0;i<size;i++)
			{
			}
			//System.out.println(Q);
			
			System.out.println("Output:"+dequeOperations(Q,arr));
		}
		else if (g.equalsIgnoreCase("chars"))
		{
			System.out.println("enter the length of deque ");
			int size=sc.nextInt();
			for(int m=0;m<size;m++)
			{
			System.out.println("enter the value to Q:");
			String a=sc.next();
			int j=a.length();
			if(j>1)
		      {
				System.out.println("enter correct input");
		         }
			else {
				Q.add(a.charAt(0));
			}
			
			//System.out.println(dequeOperations(Q,arr));
			
			
			}
			System.out.println("Output"+dequeOperations(Q,arr));
			//
		}
		
		else {
			System.out.println("choose correct one");
		}
		
		
		
		
		
		
	}

}
