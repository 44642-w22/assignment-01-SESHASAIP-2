package AssignmentPackage;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Scanner;

public class Problem2 {
	public static LinkedList<Integer> findingPairs(LinkedList<Integer> L1, int k)
	{
		LinkedList<Integer> L2 = new LinkedList<>();
		ListIterator<Integer> it = L1.listIterator();
		ArrayList<Integer> arr = new ArrayList<>();
		while(it.hasNext()) {
			int b= it.next();
			if(it.hasNext())
			{
				int a= it.next();
				
				int c= it.previous();
				//System.out.println(c);
				//System.out.println("iteration"+a+" "+b);
				if(a+b== k)
				{
					
					arr.add(b);
					arr.add(a);
					//System.out.println(arr);
				
					L2.addAll(arr);
					arr.removeAll(arr);
				}
				
			}
			
		}
		//System.out.println(L2);
		
		return L2;
		
	}
	public static void main(String[] args) {
		LinkedList<Integer> L1 = new LinkedList<>();
		System.out.println("Enter the size of the linked list");
		int i =1;
		Scanner sc = new Scanner(System.in);
		int size = sc.nextInt();
		
		while(i<=size)
		{
			System.out.println("Enter the value to be abbed into linkedlist:");
			L1.add(sc.nextInt());
			i++;
			//System.out.println(L1);
			
		}
		System.out.println("enter the sum value(K):");
		
		//System.out.println(findingPairs(L1,));
		System.out.println("Output: "+Problem2.findingPairs(L1,sc.nextInt()));
		
		
	}
	

}
