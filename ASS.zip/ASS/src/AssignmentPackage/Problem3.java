package AssignmentPackage;

import java.util.ArrayList;
import java.util.Scanner;

public class Problem3 {
public static int findingMaximumValue(ArrayList<Integer> A1)
{
	int max =Integer.MIN_VALUE;
	//ArrayList<Integer> A1 = new ArrayList<>();
	if(A1.isEmpty())
	{
		return max;
	}
	else
	{
    for(int i:A1)
    {
    	if(i>max)
    	{
    		max=i;
    		
    	}
    	
    }
	
	return max;
	
}
}
public static void main(String[] args) {
	System.out.println("enter the size of arraylist:");
	Scanner sc = new Scanner(System.in);
	ArrayList<Integer> A1 = new ArrayList<>();
	int size = sc.nextInt();
	for(int i=0;i<size;i++)
	{
		System.out.println("enter the value into arraylist:");
		A1.add(sc.nextInt());
		
	}
	System.out.println("Output: "+findingMaximumValue(A1));
}

}
