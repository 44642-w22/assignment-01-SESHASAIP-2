package AssignmentPackage;

import java.util.ArrayList;
import java.util.Scanner;

public class Problem4 {

	public static ArrayList<String> assigingStrings(ArrayList<String> A1)
	{
		if(A1.isEmpty())
		{
		  return A1;	
		}
		else
		{
			for(int i=0;i<A1.size();i++)
			{
				for(int j=i+1;j<A1.size();j++)
				{
					if(A1.get(i).length()>A1.get(j).length())
					{
						String temp = A1.get(i) ;
						A1.set(i,A1.get(j));
						A1.set(j,temp);
						//System.out.println(A1.get(i));
						//System.out.println(A1.get(j));
						
						
					}
					else if(A1.get(i).length()==A1.get(j).length()) {
						A1.set(i,A1.get(i));
						
						
					}
				}
				
			}
			return A1;
		}
		
		
		
	}
	public static void main(String[] args) {
		System.out.println("enter the size of arraylist:");
		Scanner sc = new Scanner(System.in);
		ArrayList<String> A1 = new ArrayList<>();
		int size = sc.nextInt();
		for(int i=0;i<size;i++)
		{
			System.out.println("enter the value into arraylist:");
			A1.add(sc.next());
			
		}
		System.out.println("Output: "+assigingStrings(A1));
	}
}
