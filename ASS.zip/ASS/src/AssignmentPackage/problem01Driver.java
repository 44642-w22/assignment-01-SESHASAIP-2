package AssignmentPackage;

import java.util.LinkedList;
import java.util.Scanner;

public class problem01Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Problem01 obj = new Problem01();
		LinkedList<Integer> L1 = new LinkedList<>();
		System.out.println("Enter the size of the linked list");
		int i =1;
		Scanner sc = new Scanner(System.in);
		int size = sc.nextInt();
		
		while(i<=size)
		{
			System.out.println("Enter the value to be abbed into linkedlist:");
			L1.add(sc.nextInt());
			i++;
			//System.out.println(L1);
			
		}
		System.out.println("Output: "+obj.findingPerfectNumber(L1));
		

	}

}
