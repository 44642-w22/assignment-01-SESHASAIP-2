package AssignmentPackage;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Scanner;

public class problem05 {
	public static boolean findingBalenceExpression(String ii)
	{
		Deque<Character> stack= new ArrayDeque<Character>();
		
			for(int k=0;k<ii.length();k++)
			{
				char x=ii.charAt(k);
				if(x == '(' || x == '[' || x == '{')
				{
					stack.push(x);
					continue;
				}
				if (stack.isEmpty())
	                return false;
				char check;
				switch (x) {
	            case ')':
	                check = stack.pop();
	                if (check == '{' || check == '[')
	                    return false;
	                break;
	 
	            case '}':
	                check = stack.pop();
	                if (check == '(' || check == '[')
	                    return false;
	                break;
	            case ']':
	                check = stack.pop();
	                if (check == '(' || check == '{')
	                    return false;
	                break;
	                
	                
			}
		
		
	//	return false;
		
	}
			return (stack.isEmpty());

}
	 public static void main(String[] args)
	    {
	        //String expr = "([{}])";
		 Scanner sc = new Scanner(System.in);
		 System.out.println("enter the string to check blanced or not:");
		 String expr = sc.nextLine();
		 if(findingBalenceExpression(expr))
		 {
		 System.out.println("Output: True");
		 }
		 else
		 {
			 System.out.println("Output: False");
		 }
		 
		 
	 
	       
	    }
}
