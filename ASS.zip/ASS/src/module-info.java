module ASS {
}